class TaskManager {
    constructor() {
        this.users = JSON.parse(localStorage.getItem('users')) || [];
        this.tasks = JSON.parse(localStorage.getItem('tasks')) || {};
        this.currentUser = null;
        this.editingIndex = null;
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.migrateLegacyTasks();
        this.renderUsers();
    }

    migrateLegacyTasks() {
        Object.keys(this.tasks).forEach(user => {
            this.tasks[user] = this.tasks[user].map(task => 
                typeof task === 'string' ? { text: task, completed: false } : task
            );
        });
    }

    setupEventListeners() {
        document.getElementById('addUserBtn').addEventListener('click', () => this.addUser());
        document.getElementById('addTaskBtn').addEventListener('click', () => this.addTask());
        document.getElementById('userInput').addEventListener('keypress', e => e.key === 'Enter' && this.addUser());
        document.getElementById('taskInput').addEventListener('keypress', e => e.key === 'Enter' && this.addTask());
    }

    addUser() {
        const input = document.getElementById('userInput');
        const username = this.sanitize(input.value.trim());
        
        if (!username) return this.showError('Please enter a username');
        if (this.users.some(u => u.toLowerCase() === username.toLowerCase())) {
            return this.showError('Username already exists');
        }

        this.users.push(username);
        this.tasks[username] = [];
        input.value = '';
        this.saveData();
        this.renderUsers();
    }

    removeUser(username) {
        this.users = this.users.filter(u => u !== username);
        delete this.tasks[username];
        this.saveData();
        this.renderUsers();
    }

    addTask() {
        const input = document.getElementById('taskInput');
        const text = this.sanitize(input.value.trim());
        
        if (!text) return this.showError('Please enter a task');
        
        if (this.editingIndex !== null) {
            this.tasks[this.currentUser][this.editingIndex].text = text;
            this.editingIndex = null;
        } else {
            this.tasks[this.currentUser].push({ text, completed: false });
        }
        
        input.value = '';
        this.saveData();
        this.renderTasks();
    }

    toggleTask(index) {
        this.tasks[this.currentUser][index].completed = !this.tasks[this.currentUser][index].completed;
        this.saveData();
        this.renderTasks();
    }

    editTask(index) {
        document.getElementById('taskInput').value = this.tasks[this.currentUser][index].text;
        this.editingIndex = index;
    }

    deleteTask(index) {
        this.tasks[this.currentUser].splice(index, 1);
        this.saveData();
        this.renderTasks();
    }

    showTasks(username) {
        this.currentUser = username;
        document.getElementById('taskHeader').textContent = `${username}'s Tasks`;
        document.getElementById('homePage').classList.remove('active');
        setTimeout(() => {
            document.getElementById('taskPage').classList.add('active');
        }, 300);
        this.renderTasks();
        document.getElementById('taskInput').focus();
    }

    goBack() {
        document.getElementById('taskPage').classList.remove('active');
        setTimeout(() => {
            document.getElementById('homePage').classList.add('active');
        }, 300);
        this.editingIndex = null;
        document.getElementById('taskInput').value = '';
    }

    renderUsers() {
        const list = document.getElementById('userList');
        list.innerHTML = this.users.length ? '' : '<div class="empty-state">No users found</div>';
        
        this.users.forEach(username => {
            const tasks = this.tasks[username] || [];
            const completed = tasks.filter(t => t.completed).length;
            const progress = tasks.length ? (completed / tasks.length * 100) : 0;

            const item = document.createElement('li');
            item.className = 'user-item';
            item.innerHTML = `
                <div class="user-info">
                    <h3>${username}</h3>
                    <div class="progress-container">
                        <div class="progress-bar" style="width: ${progress}%"></div>
                    </div>
                    <small>${completed}/${tasks.length} tasks completed</small>
                </div>
                <div class="task-actions">
                    <button class="btn primary" onclick="taskManager.showTasks('${username}')">
                        <i class="fas fa-tasks"></i> Manage
                    </button>
                    <button class="btn danger" onclick="taskManager.removeUser('${username}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            list.appendChild(item);
        });
    }

    renderTasks() {
        const list = document.getElementById('taskList');
        const tasks = this.tasks[this.currentUser] || [];
        list.innerHTML = tasks.length ? '' : '<div class="empty-state">No tasks found</div>';
        
        tasks.forEach((task, index) => {
            const item = document.createElement('li');
            item.className = `task-item ${task.completed ? 'completed' : ''}`;
            item.innerHTML = `
                <div class="task-info">
                    <input type="checkbox" ${task.completed ? 'checked' : ''} 
                           onchange="taskManager.toggleTask(${index})">
                    <span class="task-text">${task.text}</span>
                </div>
                <div class="task-actions">
                    <button class="btn warning" onclick="taskManager.editTask(${index})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn danger" onclick="taskManager.deleteTask(${index})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            list.appendChild(item);
        });
    }

    sanitize(input) {
        return input.replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    saveData() {
        localStorage.setItem('users', JSON.stringify(this.users));
        localStorage.setItem('tasks', JSON.stringify(this.tasks));
    }

    showError(message) {
        const error = document.createElement('div');
        error.className = 'error-message';
        error.textContent = message;
        document.body.appendChild(error);
        setTimeout(() => error.remove(), 3000);
    }
}

const taskManager = new TaskManager();